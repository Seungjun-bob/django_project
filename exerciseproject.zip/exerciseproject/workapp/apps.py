from django.apps import AppConfig


class WorkappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'workapp'
